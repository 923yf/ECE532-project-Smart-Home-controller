#ifndef PMODALS_H
#define PMODALS_H

/****************** Include Files ********************/

#include "xil_types.h"
#include "xspi.h"
#include "xspi_l.h"
#include "xstatus.h"

/* ------------------------------------------------------------ */
/*                  Definitions                                 */
/* ------------------------------------------------------------ */

typedef struct PmodALS {
   XSpi ALSSpi;
} PmodALS;

/* ------------------------------------------------------------ */
/*                  Procedure Declarations                      */
/* ------------------------------------------------------------ */

XStatus ALS_begin(PmodALS *InstancePtr, u32 SPI_Address);
XStatus ALS_SPIInit(XSpi *SpiInstancePtr);
u8 ALS_read(PmodALS *InstancePtr);

#endif // PMODALS_H
