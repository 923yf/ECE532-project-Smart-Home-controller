/******************************************************************************/
/*                                                                            */
/* main.c -- Demonstration of PmodALS use and OLED display                  */
#include "PmodALS.h"
#include "PmodOLEDrgb.h"
#include "sleep.h"
#include "xil_cache.h"
#include "xil_types.h"
#include "xil_printf.h"
#include "xparameters.h"
#include <stdio.h>
#include <string.h>


void DemoInitialize();
void DemoRun();
void DemoCleanup();
void EnableCaches();
void DisableCaches();

volatile unsigned int* led = (unsigned int*) XPAR_AXI_GPIO_1_BASEADDR;
volatile unsigned int* swt = (unsigned int*) XPAR_AXI_GPIO_0_BASEADDR;
PmodALS ALS;
PmodOLEDrgb oledrgb;

int main(void) {

	print("Hello World\n\r");

//	 while(1)
//	 {
//	 *led = *swt;
//	 xil_printf("Light = %d\n\r",* swt);
//	 }

   DemoInitialize();
   DemoRun();
   DemoCleanup();

   print("Game over\n\r");
   return 0;
}

void DemoInitialize() {
   EnableCaches();
   ALS_begin(&ALS, XPAR_PMODALS_0_AXI_LITE_SPI_BASEADDR);
   OLEDrgb_begin(&oledrgb, XPAR_PMODOLEDRGB_0_AXI_LITE_GPIO_BASEADDR,
		   XPAR_PMODOLEDRGB_0_AXI_LITE_SPI_BASEADDR);
}

void DemoRun() {

	     //DemoInitialize();
         OLEDrgb_SetCursor(&oledrgb, 3, 1);
         OLEDrgb_PutString(&oledrgb, "DEMO");

         OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255));
         OLEDrgb_SetCursor(&oledrgb, 1, 6);
         OLEDrgb_PutString(&oledrgb, "LIGHT:");
         u8 light;

   while (1) {

	  // while(*swt){
		   //OLEDrgb reset

	   OLEDrgb_SetCursor(&oledrgb, 7, 6);
	   OLEDrgb_PutChar(&oledrgb, 0);
	   OLEDrgb_SetCursor(&oledrgb, 8, 6);
	   OLEDrgb_PutChar(&oledrgb, 0);
	   OLEDrgb_SetCursor(&oledrgb, 9, 6);
	   OLEDrgb_PutChar(&oledrgb, 0);
	   OLEDrgb_SetCursor(&oledrgb, 1, 4);
	   OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
	   OLEDrgb_PutString(&oledrgb, "          ");

      light = ALS_read(&ALS);
      xil_printf("Light = %d\n\r", light);
      OLEDrgb_SetCursor(&oledrgb, 1, 2);
      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
      OLEDrgb_PutChar(&oledrgb, *swt);

      if (light >=200 && light<=255){

    	  *led = 0;
    	  OLEDrgb_SetCursor(&oledrgb, 1, 4);
    	  OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
    	  OLEDrgb_PutString(&oledrgb, "EXTREME");

      }//control LED on chip
      else if(light >=160 && light<200){

    	  *led = 0;
    	   OLEDrgb_SetCursor(&oledrgb, 1, 4);
    	   OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
    	   OLEDrgb_PutString(&oledrgb, "HIGH");

      }
      else if(light >=120 && light<160){

    	  *led = 0;
    	  OLEDrgb_SetCursor(&oledrgb, 1, 4);
    	      	   OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
    	      	   OLEDrgb_PutString(&oledrgb, "HIGH");

      }
      else if(light >=80 && light<120){

    	  *led = 3;
    	  OLEDrgb_SetCursor(&oledrgb, 1, 4);
    	   OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
    	   OLEDrgb_PutString(&oledrgb, "MEDIAN");

      }
      else if(light >=40 && light<80){

    	  *led = 3;OLEDrgb_SetCursor(&oledrgb, 1, 4);
   	      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
   	      OLEDrgb_PutString(&oledrgb, "MEDIAN");

      }
      else if(light >=20 && light<40){

    	  *led = 3;OLEDrgb_SetCursor(&oledrgb, 1, 4);
   	      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
   	      OLEDrgb_PutString(&oledrgb, "MEDIAN");

      }
      else if(light >=10 && light<20){

    	  *led = 15;OLEDrgb_SetCursor(&oledrgb, 1, 4);
   	      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
   	      OLEDrgb_PutString(&oledrgb, "WEAK");

      }
      else if(light >=2 && light<10){

    	  *led = 31;OLEDrgb_SetCursor(&oledrgb, 1, 4);
   	      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
   	      OLEDrgb_PutString(&oledrgb, "WEAK");

      }
      else{

    	  *led = 255;
    	  OLEDrgb_SetCursor(&oledrgb, 1, 4);
   	      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(0, 0, 255)); 
   	      OLEDrgb_PutString(&oledrgb, "WEAK");


      }

      OLEDrgb_SetFontColor(&oledrgb, OLEDrgb_BuildRGB(255, 0, 255));
      if (light == 0){
          OLEDrgb_SetCursor(&oledrgb, 7, 6);
          OLEDrgb_PutChar(&oledrgb, 0);
          OLEDrgb_SetCursor(&oledrgb, 8, 6);
          OLEDrgb_PutChar(&oledrgb, 0);
          OLEDrgb_SetCursor(&oledrgb, 9, 6);
          OLEDrgb_PutChar(&oledrgb, 48);
      }
      else if(light > 0&& light <=99){

    	  char num1 = light/10;
    	  char num0 = light-num1*10;
    	  OLEDrgb_SetCursor(&oledrgb, 7, 6);
          OLEDrgb_PutChar(&oledrgb, 0);
          OLEDrgb_SetCursor(&oledrgb, 8, 6);
          OLEDrgb_PutChar(&oledrgb, num1+48);
          OLEDrgb_SetCursor(&oledrgb, 9, 6);
          OLEDrgb_PutChar(&oledrgb, num0+48);
      }else{
    	  char num2 = light/100;
    	  char num1 = (light - num2*100)/10;
    	  char num0 = light-num2*100-num1*10;

    	  OLEDrgb_SetCursor(&oledrgb, 7, 6);
    	  OLEDrgb_PutChar(&oledrgb, num2+48);
    	  OLEDrgb_SetCursor(&oledrgb, 8, 6);
    	  OLEDrgb_PutChar(&oledrgb, num1+48);
    	  OLEDrgb_SetCursor(&oledrgb, 9, 6);
    	  OLEDrgb_PutChar(&oledrgb, num0+48);
      }
      // Delay
      //sleep(1);
   }

}

void DemoCleanup() {
   DisableCaches();
}

void EnableCaches() {
#ifdef __MICROBLAZE__
#ifdef XPAR_MICROBLAZE_USE_ICACHE
   Xil_ICacheEnable();
#endif
#ifdef XPAR_MICROBLAZE_USE_DCACHE
   Xil_DCacheEnable();
#endif
#endif
}

void DisableCaches() {
#ifdef __MICROBLAZE__
#ifdef XPAR_MICROBLAZE_USE_DCACHE
   Xil_DCacheDisable();
#endif
#ifdef XPAR_MICROBLAZE_USE_ICACHE
   Xil_ICacheDisable();
#endif
#endif
}






